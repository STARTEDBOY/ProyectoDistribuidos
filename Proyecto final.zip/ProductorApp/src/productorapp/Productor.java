package productorapp;

import com.rabbitmq.client.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Productor {
    private final static String QUEUE_NAME = "cola_mensajes_productor";
    private final static String QUEUE_CONSUMER = "cola_mensajes_consumidor";

    private static Connection connection = null;
    private static Channel channel = null;

    public static void main(String[] argv) throws Exception {
        JFrame frame = new JFrame("Control de Productor");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        JButton botonArriba = new JButton("Arriba");
        JButton botonAbajo = new JButton("Abajo");
        JButton botonIzquierda = new JButton("Izquierda");
        JButton botonDerecha = new JButton("Derecha");

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(botonArriba);
        panel.add(botonAbajo);
        panel.add(botonIzquierda);
        panel.add(botonDerecha);

        frame.getContentPane().add(panel);
        frame.setVisible(true);

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        factory.setPort(5672); // Puerto normal
        factory.setUsername("started");
        factory.setPassword("started");

        connection = factory.newConnection();
        channel = connection.createChannel();

        channel.queueDeclare(QUEUE_NAME, false, false, false, null);
        channel.queueDeclare(QUEUE_CONSUMER, false, false, false, null);

        ActionListener action = e -> {
            String comando = ((JButton) e.getSource()).getText();
            enviarMensaje(comando);
        };

        botonArriba.addActionListener(action);
        botonAbajo.addActionListener(action);
        botonIzquierda.addActionListener(action);
        botonDerecha.addActionListener(action);

        // Hilo para recibir respuestas del consumidor
        new Thread(() -> {
            try {
                DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                    String message = new String(delivery.getBody(), "UTF-8");
                    System.out.println("Respuesta del consumidor: " + message);
                };
                channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> {});
            } catch (Exception e) {
                System.err.println("Error al recibir respuesta: " + e.getMessage());
            }
        }).start();
    }

    private static void enviarMensaje(String message) {
        try {
            if (message.matches("Arriba|Abajo|Izquierda|Derecha")) {
                channel.basicPublish("", QUEUE_CONSUMER, null, message.getBytes());
                System.out.println("Enviado: " + message);
            } else {
                System.out.println("Comando inválido: " + message);
            }
        } catch (Exception ex) {
            System.err.println("Error al enviar mensaje: " + ex.getMessage());
        }
    }
}








