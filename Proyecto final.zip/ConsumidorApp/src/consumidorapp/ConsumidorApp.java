
package consumidorapp;

public class ConsumidorApp {

    public static void main(String[] args) {
    }
    
}
